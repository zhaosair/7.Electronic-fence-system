(function(myWindow) {
		myWindow.basePath="http://localhost:8099/fence";
})(window);
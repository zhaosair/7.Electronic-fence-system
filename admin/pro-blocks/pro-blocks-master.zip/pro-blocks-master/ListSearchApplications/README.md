# @umi-blocks/ant-design-pro/searchlistapplications

SearchListApplications

## Usage

```sh
umi block add ant-design-pro/searchlistapplications
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

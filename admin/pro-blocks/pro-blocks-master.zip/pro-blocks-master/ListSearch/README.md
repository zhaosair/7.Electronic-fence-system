# @umi-blocks/ant-design-pro/searchlist

SearchList

## Usage

```sh
umi block add ant-design-pro/searchlist
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

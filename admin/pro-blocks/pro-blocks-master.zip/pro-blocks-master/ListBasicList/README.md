# @umi-blocks/ant-design-pro/basiclist

BasicList

## Usage

```sh
umi block add ant-design-pro/basiclist
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

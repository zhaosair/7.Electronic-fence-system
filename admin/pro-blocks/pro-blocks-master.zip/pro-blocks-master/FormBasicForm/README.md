# @umi-blocks/ant-design-pro/basicform

BasicForm

## Usage

```sh
umi block add ant-design-pro/basicform
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

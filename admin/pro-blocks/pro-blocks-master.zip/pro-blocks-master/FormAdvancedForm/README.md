# @umi-blocks/ant-design-pro/advancedform

AdvancedForm

## Usage

```sh
umi block add ant-design-pro/advancedform
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

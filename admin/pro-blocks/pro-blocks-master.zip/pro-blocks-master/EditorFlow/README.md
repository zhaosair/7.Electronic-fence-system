# @umi-blocks/ant-design-pro/flow

flow

## Usage

```sh
umi block add ant-design-pro/flow
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

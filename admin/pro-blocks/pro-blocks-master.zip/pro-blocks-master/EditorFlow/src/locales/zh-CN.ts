export default {
  'BLOCK_NAME.description': '千言万语不如一张图，流程图是表示算法思路的好方法',
};

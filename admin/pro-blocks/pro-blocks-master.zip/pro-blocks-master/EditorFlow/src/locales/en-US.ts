export default {
  'BLOCK_NAME.description':
    'The flow chart is an excellent way to represent the idea of the algorithm',
};

import FlowDetailPanel from './FlowDetailPanel';
import KoniDetailPanel from './KoniDetailPanel';
import MindDetailPanel from './MindDetailPanel';

export { FlowDetailPanel, MindDetailPanel, KoniDetailPanel };

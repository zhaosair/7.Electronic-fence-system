# @umi-blocks/ant-design-pro/workplace

Workplace

## Usage

```sh
umi block add ant-design-pro/Workplace
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

# @umi-blocks/ant-design-pro/userregister

UserRegister

## Usage

```sh
umi block add ant-design-pro/UserRegister
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

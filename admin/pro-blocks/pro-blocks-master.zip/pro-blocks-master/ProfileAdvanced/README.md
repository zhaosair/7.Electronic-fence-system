# @umi-blocks/ant-design-pro/advancedprofile

AdvancedProfile

## Usage

```sh
umi block add ant-design-pro/advancedprofile
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

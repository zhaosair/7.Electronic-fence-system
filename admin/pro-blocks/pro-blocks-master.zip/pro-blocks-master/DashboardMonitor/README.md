# @umi-blocks/ant-design-pro/monitor

Monitor

## Usage

```sh
umi block add ant-design-pro/monitor
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

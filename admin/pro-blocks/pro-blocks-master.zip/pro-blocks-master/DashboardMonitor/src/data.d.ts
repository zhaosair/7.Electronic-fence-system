export type TagType = {
  name: string;
  value: string;
  type: string;
};

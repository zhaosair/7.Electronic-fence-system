# @umi-blocks/ant-design-pro/accountsettings

AccountSettings

## Usage

```sh
umi block add ant-design-pro/AccountSettings
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

# @umi-blocks/ant-design-pro/analysis

Analysis

## Usage

```sh
umi block add ant-design-pro/analysis
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

# @umi-blocks/ant-design-pro/basicprofile

BasicProfile

## Usage

```sh
umi block add ant-design-pro/basicprofile
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

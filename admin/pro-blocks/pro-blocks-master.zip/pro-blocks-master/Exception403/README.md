# @umi-blocks/ant-design-pro/exception403

Exception403

## Usage

```sh
umi block add ant-design-pro/exception403
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

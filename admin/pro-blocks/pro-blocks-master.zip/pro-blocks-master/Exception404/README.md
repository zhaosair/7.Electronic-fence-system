# @umi-blocks/ant-design-pro/exception404

Exception404

## Usage

```sh
umi block add ant-design-pro/exception404
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

# @umi-blocks/ant-design-pro/accountcenter

AccountCenter

## Usage

```sh
umi block add ant-design-pro/AccountCenter
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

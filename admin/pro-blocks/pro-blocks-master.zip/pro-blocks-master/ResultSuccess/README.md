# @umi-blocks/ant-design-pro/resultsuccess

ResultSuccess

## Usage

```sh
umi block add ant-design-pro/resultsuccess
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

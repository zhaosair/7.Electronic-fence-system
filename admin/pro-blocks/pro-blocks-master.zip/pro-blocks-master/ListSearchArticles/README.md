# @umi-blocks/ant-design-pro/searchlistarticles

SearchListArticles

## Usage

```sh
umi block add ant-design-pro/searchlistarticles
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

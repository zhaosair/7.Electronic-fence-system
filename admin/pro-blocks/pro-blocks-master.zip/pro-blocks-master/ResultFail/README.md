# @umi-blocks/ant-design-pro/resulterror

ResultError

## Usage

```sh
umi block add ant-design-pro/resulterror
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

export default {
  'BLOCK_NAME.error.title': '提交失败',
  'BLOCK_NAME.error.description': '请核对并修改以下信息后，再重新提交。',
  'BLOCK_NAME.error.hint-title': '您提交的内容有如下错误：',
  'BLOCK_NAME.error.hint-text1': '您的账户已被冻结',
  'BLOCK_NAME.error.hint-btn1': '立即解冻',
  'BLOCK_NAME.error.hint-text2': '您的账户还不具备申请资格',
  'BLOCK_NAME.error.hint-btn2': '立即升级',
  'BLOCK_NAME.error.btn-text': '返回修改',
};

export default {
  'BLOCK_NAME.error.title': '提交失敗',
  'BLOCK_NAME.error.description': '請核對並修改以下信息後，再重新提交。',
  'BLOCK_NAME.error.hint-title': '您提交的內容有如下錯誤：',
  'BLOCK_NAME.error.hint-text1': '您的賬戶已被凍結',
  'BLOCK_NAME.error.hint-btn1': '立即解凍',
  'BLOCK_NAME.error.hint-text2': '您的賬戶還不具備申請資格',
  'BLOCK_NAME.error.hint-btn2': '立即升級',
  'BLOCK_NAME.error.btn-text': '返回修改',
};

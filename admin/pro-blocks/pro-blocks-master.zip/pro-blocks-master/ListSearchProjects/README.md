# @umi-blocks/ant-design-pro/searchlistprojects

SearchListProjects

## Usage

```sh
umi block add ant-design-pro/searchlistprojects
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

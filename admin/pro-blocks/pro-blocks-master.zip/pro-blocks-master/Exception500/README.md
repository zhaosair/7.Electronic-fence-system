# @umi-blocks/ant-design-pro/exception500

Exception500

## Usage

```sh
umi block add ant-design-pro/exception500
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT

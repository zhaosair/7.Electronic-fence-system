export default {
  'BLOCK_NAME.exception.back': '返回首頁',
  'BLOCK_NAME.description.500': '抱歉，服務器出錯了。',
};

export default {
  'BLOCK_NAME.exception.back': 'Voltar para Início',
  'BLOCK_NAME.description.500': 'Desculpe, o servidor está reportando um erro.',
};

export default {
  'BLOCK_NAME.exception.back': '返回首页',
  'BLOCK_NAME.description.500': '抱歉，服务器出错了。',
};

export default {
  'BLOCK_NAME.exception.back': 'Back to home',
  'BLOCK_NAME.description.500': 'Sorry, the server is reporting an error.',
};

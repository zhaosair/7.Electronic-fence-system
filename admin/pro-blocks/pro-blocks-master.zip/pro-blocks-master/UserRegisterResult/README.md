# @umi-blocks/ant-design-pro/userregisterresult

UserRegisterResult

## Usage

```sh
umi block add ant-design-pro/UserRegisterResult
```

## SNAPSHOT

![SNAPSHOT](./snapshot.png)

## LICENSE

MIT
